"""Actenon-Permit CLI.

Commands:
    permit init-key                     generate and persist a stable dev signing key
    permit issue <policy.yaml>          compile a policy file to a signed grant
    permit revoke <agent_id>            kill switch — revoke all grants for an agent
    permit watch                        live TUI: pending approvals, a/d to approve/deny
    permit ledger [--verify]            print the action log (and verify the chain)
    permit demo [--auto-approve]        run the built-in 7-step scenario (v0 in-process)
    permit demo --mode gateway          run the demo through the v1 out-of-process gateway
    permit serve [--with-gateway]       run the control plane (+ v1 gateway if requested)
    permit mcp-serve                    run the v1 MCP stdio server (JSON-RPC over stdin/stdout)
    permit attenuate <grant_id> ...     derive a strictly-weaker sub-grant (UCAN-style)
    permit mint-token <grant_id>        mint a v1 bearer token for a grant
"""

from __future__ import annotations

import contextlib
import json
import os
import sys
import time
from datetime import UTC
from pathlib import Path
from typing import Any

import typer

from . import __version__
from .ledger import Ledger
from .model import Grant, GrantStatus
from .policy import compile_policy, load_policy
from .state import get_default_store

app = typer.Typer(
    name="permit",
    help="Actenon-Permit: an authority broker for AI agents.",
    no_args_is_help=True,
    add_completion=False,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _print_grant(g: Grant) -> None:
    typer.echo(json.dumps(json.loads(g.model_dump_json()), indent=2))


def _reset_db_for_demo() -> None:
    """Wipe the local DB so the demo runs from a clean state every time."""
    db_path = os.environ.get("ACTENON_DB_PATH", "actenon.db")
    for suffix in ("", "-journal", "-wal", "-shm"):
        p = Path(db_path + suffix)
        if p.exists():
            with contextlib.suppress(OSError):
                p.unlink()


def _build_demo_gateway():
    """Build a Gateway wired to the demo's mock providers.

    Used by `permit serve --with-gateway` and `permit mcp-serve` so the demo
    tools (refund / charge / send_email) work out of the box. Production
    deployments should build their own Gateway with their own ToolRegistry.
    """
    os.environ.setdefault("MOCK_STRIPE_KEY", "sk_mock_123")

    from ._mock_providers import mock_send_email, mock_stripe_charge, mock_stripe_refund
    from .broker import Broker
    from .enforce import AutoApproveGate
    from .gateway import Gateway, ToolRegistry
    from .pdp import PDP
    from .state import get_default_store

    store = get_default_store()
    ledger = Ledger(store)
    pdp = PDP(store, ledger)
    broker = Broker(pdp)
    tools = ToolRegistry()
    tools.register(
        "refund",
        action_type="payment.refund",
        target="stripe",
        description="Issue a refund via the (mock) Stripe provider.",
        input_schema={
            "type": "object",
            "properties": {
                "amount": {"type": "number", "description": "Amount to refund, in major currency units."},
                "reason": {"type": "string", "default": "customer_request"},
            },
            "required": ["amount"],
        },
        cost_from="amount",
        credential_name="MOCK_STRIPE_KEY",
        real_call=lambda secret, amount, reason="customer_request": mock_stripe_refund(secret, amount, reason),
    )
    tools.register(
        "charge",
        action_type="payment.charge",
        target="stripe",
        description="Charge a card via the (mock) Stripe provider.",
        input_schema={
            "type": "object",
            "properties": {
                "amount": {"type": "number"},
                "description": {"type": "string", "default": ""},
            },
            "required": ["amount"],
        },
        cost_from="amount",
        credential_name="MOCK_STRIPE_KEY",
        real_call=lambda secret, amount, description="": mock_stripe_charge(secret, amount, description),
    )
    tools.register(
        "send_email",
        action_type="email.send",
        target="smtp",
        description="Send an email via the (mock) SMTP provider.",
        input_schema={
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "subject": {"type": "string"},
                "body": {"type": "string", "default": ""},
            },
            "required": ["to", "subject"],
        },
        credential_name="MOCK_STRIPE_KEY",
        real_call=lambda secret, to, subject, body="": mock_send_email(secret, to, subject, body),
    )
    return Gateway(
        state=store, ledger=ledger, pdp=pdp, broker=broker, tools=tools,
        approval_gate=AutoApproveGate(),
    )


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@app.command(name="init-key")
def init_key(
    path: Path | None = typer.Option(
        None,
        "--path",
        "-p",
        help="Where to write the key. Default: ~/.actenon-permit/signing-key",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Overwrite an existing key file. DANGEROUS — invalidates all existing tokens.",
    ),
) -> None:
    """Generate and persist a stable dev signing key.

    By default, writes a 32-byte random hex key to
    ``~/.actenon-permit/signing-key`` (mode 0600). Once written, every
    ``permit`` command in any process will use this key, so grants minted
    by ``permit issue`` / ``permit mint-token`` will validate in
    ``permit serve`` even across restarts.

    Without this, Actenon-Permit generates an EPHEMERAL key per process,
    which means tokens minted in one ``permit`` invocation won't validate
    in the next. The demo works because it's all one process, but any
    multi-process workflow (issue in one terminal, serve in another) needs
    a stable key.

    The key file is read by ``_get_signing_key()`` AFTER the
    ``ACTENON_SIGNING_KEY`` env var, so env vars still win in production.
    """
    import os
    import secrets

    from .model import _default_key_file_path

    target = path or _default_key_file_path()
    if target.exists() and not force:
        typer.echo(
            f"ERROR: {target} already exists. "
            f"Use --force to overwrite (this will invalidate all existing tokens).",
            err=True,
        )
        raise typer.Exit(code=1)

    target.parent.mkdir(parents=True, exist_ok=True)
    key = secrets.token_hex(32)
    # Write with mode 0600 — the key is the root of trust for all grants.
    fd = os.open(str(target), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, key.encode("utf-8"))
    finally:
        os.close(fd)
    # Ensure the mode is correct even if the file already existed.
    os.chmod(target, 0o600)

    typer.echo(f"wrote stable dev signing key to {target} (mode 0600)")
    typer.echo("  grants minted with this key will validate across process restarts.")
    typer.echo("  to use a different key in production, set ACTENON_SIGNING_KEY instead.")


@app.command(name="init-keys")
def init_keys(
    path: Path | None = typer.Option(
        None,
        "--path",
        "-p",
        help="Where to write the keypair. Default: ~/.actenon-permit/ed25519-key.json",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Overwrite an existing keypair. DANGEROUS — invalidates all existing PCCBs.",
    ),
) -> None:
    """Generate and persist an Ed25519 keypair for production-grade PCCB signing.

    Phase 4 production hardening: Ed25519 is the real asymmetric signature
    algorithm. Unlike the HMAC dev key, the private key never leaves the
    keypair file, and verification can be done with only the public key.

    Once written, every PCCB minted by permit (and every PCCB verified at
    the gateway) uses this Ed25519 keypair automatically. The kernel's
    production guardrail allows ``pilot_local_eddsa`` in production only
    with ``ACTENON_ALLOW_PILOT_LOCAL_EDDSA_IN_PRODUCTION=1`` — for a real
    production deploy, wire a KMS/HSM backend via the kernel's
    ``external_managed`` adapter instead.

    The keypair file is mode 0600. Protect it — it's the root of trust.
    """
    from .ed25519_signer import generate_ed25519_keypair, save_ed25519_keypair
    from .model import _default_key_file_path as _default_hmac_key_path  # noqa: F401 — for context

    target = path or (Path.home() / ".actenon-permit" / "ed25519-key.json")
    if target.exists() and not force:
        typer.echo(
            f"ERROR: {target} already exists. "
            f"Use --force to overwrite (this will invalidate all existing PCCBs).",
            err=True,
        )
        raise typer.Exit(code=1)

    keypair = generate_ed25519_keypair()
    save_ed25519_keypair(keypair, target)

    typer.echo(f"wrote Ed25519 keypair to {target} (mode 0600)")
    typer.echo(f"  key_id: {keypair.key_id}")
    typer.echo("  algorithm: EdDSA (Ed25519)")
    typer.echo(f"  public key (JWK x): {keypair.public_key_jwk['x'][:32]}...")
    typer.echo("")
    typer.echo("  PCCBs will now be signed with Ed25519 instead of dev-HMAC.")
    typer.echo("  To use a different key file: set ACTENON_ED25519_KEY_FILE=/path/to/key.json")
    typer.echo("  For real production: wire a KMS/HSM backend via the kernel's external_managed adapter.")


@app.command()
def issue(
    policy: Path = typer.Argument(..., help="Path to a YAML policy file."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Print only the grant id."),
) -> None:
    """Compile a policy file to a signed grant and store it."""
    policy_dict = load_policy(policy)
    grant = compile_policy(policy_dict)
    store = get_default_store()
    store.put_grant(grant)
    if quiet:
        typer.echo(grant.id)
    else:
        _print_grant(grant)


@app.command()
def revoke(
    agent_id: str = typer.Argument(..., help="Agent id whose grants to revoke."),
    grant_id: str | None = typer.Option(
        None, "--grant-id", help="Revoke a specific grant id instead of all grants for the agent."
    ),
) -> None:
    """Kill switch — revoke a grant (or all grants for an agent)."""
    store = get_default_store()
    if grant_id:
        g = store.get_grant(grant_id)
        if g is None:
            typer.echo(f"grant {grant_id} not found", err=True)
            raise typer.Exit(code=1)
        store.set_status(grant_id, GrantStatus.REVOKED)
        typer.echo(f"revoked grant {grant_id} (agent={g.agent_id})")
        return
    grants = store.list_grants(agent_id=agent_id)
    if not grants:
        typer.echo(f"no grants found for agent {agent_id}", err=True)
        raise typer.Exit(code=1)
    for g in grants:
        store.set_status(g.id, GrantStatus.REVOKED)
        typer.echo(f"revoked grant {g.id} (agent={g.agent_id})")


@app.command()
def ledger(
    verify: bool = typer.Option(False, "--verify", help="Verify the hash chain and exit."),
    grant_id: str | None = typer.Option(None, "--grant-id", help="Filter by grant id."),
    limit: int = typer.Option(1000, "--limit", help="Max entries to print."),
) -> None:
    """Print the action log (and optionally verify the chain)."""
    store = get_default_store()
    led = Ledger(store)
    if verify:
        ok = led.verify()
        typer.echo(f"chain intact: {ok}")
        raise typer.Exit(code=0 if ok else 1)
    entries = led.list_entries(grant_id=grant_id, limit=limit)
    if not entries:
        typer.echo("(ledger empty)")
        return
    for e in entries:
        typer.echo(
            f"#{e['seq']:>4}  {e['ts']}  {e['outcome']:<18}  "
            f"{e['action_type']:<22}  reason={e['reason']}  "
            f"hash={e['hash'][:12]}..."
        )


@app.command()
def watch(
    url: str = typer.Option(
        "http://127.0.0.1:7780",
        "--url",
        help="Control plane URL to poll for pending approvals.",
    ),
    once: bool = typer.Option(
        False,
        "--once",
        help="Print pending approvals once and exit (non-interactive, for scripts/CI).",
    ),
    admin_token_file: str | None = typer.Option(
        None,
        "--admin-token-file",
        envvar="ACTENON_ADMIN_TOKEN_FILE",
        help="File holding the control-plane admin token (default: ACTENON_ADMIN_TOKEN, "
        "then ~/.actenon-permit/admin-token).",
    ),
) -> None:
    """Live TUI for pending approvals. Polls the control plane's /approvals
    endpoint. Press a=approve, d=deny on the most recent pending request,
    q=quit.

    This command talks to a running `permit serve` (or `permit serve
    --with-gateway`) instance over HTTP. It does NOT hold any in-memory
    state — every action is a real API call to the control plane.
    """
    import json as _json
    import urllib.error
    import urllib.request

    from .control import read_admin_token

    token = read_admin_token(admin_token_file)
    if not token:
        typer.echo(
            "no admin token: pass --admin-token-file, set ACTENON_ADMIN_TOKEN, or run "
            "`permit serve` first (it writes ~/.actenon-permit/admin-token)",
            err=True,
        )
        raise typer.Exit(code=1)
    auth = {"Authorization": f"Bearer {token}"}

    def _get(path: str):
        req = urllib.request.Request(f"{url}{path}", method="GET", headers=auth)
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                return _json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as e:
            typer.echo(f"cannot reach control plane at {url}: {e}", err=True)
            raise typer.Exit(code=1) from e

    def _post(path: str):
        req = urllib.request.Request(f"{url}{path}", method="POST", data=b"", headers=auth)
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status == 200
        except urllib.error.HTTPError:
            return False

    # Non-interactive mode: print and exit.
    if once:
        pending = _get("/approvals")
        if not pending:
            typer.echo("(no pending approvals)")
            return
        for p in pending:
            typer.echo(
                f"{p['action_id']}  grant={p['grant_id']}  "
                f"type={p['action_type']}  reason={p['reason']}"
            )
        return

    # Interactive mode — needs a TTY.
    try:
        import termios
        import tty

        old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())
    except (ImportError, AttributeError):
        typer.echo(
            "watch: no TTY available. Use `permit watch --once` to print pending "
            "approvals non-interactively, or approve directly via the API:\n"
            "  curl -X POST -H \"Authorization: Bearer $(cat ~/.actenon-permit/admin-token)\" \\\n"
            "    http://127.0.0.1:7780/approvals/<action_id>/approve",
            err=True,
        )
        raise typer.Exit(code=1) from None

    typer.echo(f"Actenon-Permit watch — polling {url}/approvals every 0.5s")
    typer.echo("press a=approve, d=deny on the most recent pending, q=quit")
    typer.echo()
    last_seen: set[str] = set()
    current: dict[str, Any] | None = None
    try:
        while True:
            try:
                pending = _get("/approvals")
            except typer.Exit:
                raise
            except Exception:
                pending = []
            # Print newly-seen pending requests.
            for p in pending:
                if p["action_id"] not in last_seen:
                    last_seen.add(p["action_id"])
                    current = p
                    typer.echo(
                        f"\n[pending] {p['action_id']}  grant={p['grant_id']}  "
                        f"type={p['action_type']}  reason={p['reason']}"
                    )
                    typer.echo("  press a=approve, d=deny")
            # Non-blocking read of one char if available.
            ch = sys.stdin.read(1)
            if ch == "q":
                typer.echo("\nbye.")
                break
            if ch in ("a", "d") and current is not None:
                action_id = current["action_id"]
                if ch == "a":
                    ok = _post(f"/approvals/{action_id}/approve")
                    typer.echo(f"\n  approved {action_id}: {'ok' if ok else 'FAILED'}")
                else:
                    ok = _post(f"/approvals/{action_id}/deny")
                    typer.echo(f"\n  denied {action_id}: {'ok' if ok else 'FAILED'}")
                current = None
            time.sleep(0.5)
    except KeyboardInterrupt:
        typer.echo("\nbye.")
    finally:
        if old_settings is not None:
            with contextlib.suppress(Exception):
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)


def _run_uvicorn(application, host: str, port: int) -> None:
    import uvicorn

    uvicorn.run(application, host=host, port=port, log_level="info")


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Bind host (localhost only in v0)."),
    port: int = typer.Option(7780, "--port", help="Bind port."),
    with_gateway: bool = typer.Option(
        False,
        "--with-gateway",
        help="Also mount the v1 out-of-process PEP proxy (/proxy/*) on the same port.",
    ),
    admin_token_file: str | None = typer.Option(
        None,
        "--admin-token-file",
        envvar="ACTENON_ADMIN_TOKEN_FILE",
        help="File holding the control-plane admin token. Default: ACTENON_ADMIN_TOKEN, "
        "else a fresh token written 0600 to ~/.actenon-permit/admin-token.",
    ),
) -> None:
    """Run the localhost control plane (FastAPI + uvicorn).

    Control-plane routes (/grants, /approvals, /ledger) require
    `Authorization: Bearer <admin token>`; agents only use /proxy and
    /intents with their grant token. The token is never printed — only
    the path of the file that holds it.

    With --with-gateway, also mounts the v1 HTTP proxy endpoints so a single
    `permit serve --with-gateway` can host both the control plane and the
    gateway. Tools are registered from the demo's mock providers (so the
    demo works out of the box); production deployments should register their
    own tools via a custom entrypoint.
    """
    import socket

    from .control import create_app, load_or_create_admin_token

    # Pre-check: fail fast and loud if the port is taken. Uvicorn logs the
    # error but exits 0, which means a stranger would think the server is
    # running when it isn't. We'd rather exit non-zero immediately.
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
    except OSError as e:
        typer.echo(
            f"ERROR: cannot bind {host}:{port} — {e}\n"
            f"  Is another `permit serve` already running on that port?\n"
            f"  Use --port <PORT> to pick a different port.",
            err=True,
        )
        raise typer.Exit(code=1) from e

    try:
        admin_token, token_path = load_or_create_admin_token(admin_token_file)
    except (OSError, ValueError) as e:
        typer.echo(f"ERROR: cannot load the admin token: {e}", err=True)
        raise typer.Exit(code=1) from e

    gateway = None
    if with_gateway:
        gateway = _build_demo_gateway()
    application = create_app(gateway=gateway, admin_token=admin_token)
    del admin_token
    typer.echo(f"Actenon-Permit control plane starting on http://{host}:{port}", err=True)
    if token_path is not None:
        typer.echo(f"  admin token (for /grants, /approvals, /ledger): {token_path}", err=True)
    else:
        typer.echo("  admin token: from ACTENON_ADMIN_TOKEN", err=True)
    if with_gateway:
        typer.echo(f"  gateway proxy: POST http://{host}:{port}/proxy/<tool>", err=True)
    try:
        _run_uvicorn(application, host, port)
    except OSError as e:
        # Race: the port was free during pre-check but taken before uvicorn
        # bound it. Still fail loud.
        typer.echo(f"ERROR: uvicorn failed to bind: {e}", err=True)
        raise typer.Exit(code=1) from e


@app.command()
def mcp_serve(
    grant_token: str | None = typer.Option(
        None,
        "--grant-token",
        envvar="ACTENON_GRANT_TOKEN",
        help="Grant token used for tools/call when the client sends no _meta.actenon_grant.",
    ),
) -> None:
    """Run the v1 MCP stdio server (JSON-RPC 2.0 over stdin/stdout).

    The agent host (Claude Desktop, Cursor, etc.) connects to this process
    via stdio and calls tools/list + tools/call. The grant token comes from
    --grant-token / ACTENON_GRANT_TOKEN, or per call from
    params._meta.actenon_grant (which takes precedence).
    """
    from .gateway import mcp_serve as _mcp_serve

    gateway = _build_demo_gateway()
    _mcp_serve(gateway, grant_token=grant_token)


@app.command()
def attenuate(
    grant_id: str = typer.Argument(..., help="Parent grant id to attenuate."),
    agent_id: str | None = typer.Option(None, "--agent-id", help="New agent id for the child grant."),
    budget_limit: float | None = typer.Option(None, "--budget-limit", help="Smaller budget cap."),
    scopes_allow: str | None = typer.Option(
        None, "--scopes-allow", help="Comma-separated subset of parent's allow scopes."
    ),
    scopes_deny: str | None = typer.Option(
        None, "--scopes-deny", help="Comma-separated additional deny scopes."
    ),
    expires_at: str | None = typer.Option(None, "--expires-at", help="Earlier expiry (ISO-8601)."),
) -> None:
    """Derive a strictly-weaker sub-grant from an existing grant (UCAN-style)."""
    from .model import GrantStatus
    from .policy import compile_policy  # noqa: F401 — kept for future YAML attenuate
    from .state import get_default_store

    store = get_default_store()
    parent = store.get_grant(grant_id)
    if parent is None:
        typer.echo(f"parent grant {grant_id} not found", err=True)
        raise typer.Exit(code=1)
    if parent.status != GrantStatus.ACTIVE:
        typer.echo(f"parent grant status is {parent.status.value}, must be active", err=True)
        raise typer.Exit(code=1)

    from datetime import datetime

    kwargs: dict[str, Any] = {}
    if agent_id is not None:
        kwargs["agent_id"] = agent_id
    if budget_limit is not None:
        kwargs["budget_limit"] = budget_limit
    if scopes_allow is not None:
        kwargs["scopes_allow"] = [s.strip() for s in scopes_allow.split(",") if s.strip()]
    if scopes_deny is not None:
        kwargs["scopes_deny"] = [s.strip() for s in scopes_deny.split(",") if s.strip()]
    if expires_at is not None:
        dt = datetime.fromisoformat(expires_at)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        kwargs["expires_at"] = dt

    try:
        child = parent.attenuate(**kwargs)
    except ValueError as e:
        typer.echo(f"attenuation rejected: {e}", err=True)
        raise typer.Exit(code=1) from e
    store.put_grant(child)
    typer.echo(json.dumps(json.loads(child.model_dump_json()), indent=2))


@app.command()
def mint_token(
    grant_id: str = typer.Argument(..., help="Grant id to mint a bearer token for."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Print only the token (suppress warnings to stderr)."),
) -> None:
    """Mint a v1 bearer token for a grant. The token is presented to the
    gateway as the X-Actenon-Grant header."""
    from .model import suppress_dev_key_warning
    from .state import get_default_store
    from .token import grant_to_token

    # --quiet suppresses the signing-key warning at the source so the token
    # can be captured cleanly in shell pipelines like:
    #   TOKEN=$(permit mint-token $GRANT_ID --quiet)
    if quiet:
        suppress_dev_key_warning(True)

    store = get_default_store()
    g = store.get_grant(grant_id)
    if g is None:
        typer.echo(f"grant {grant_id} not found", err=True)
        raise typer.Exit(code=1)
    if not g.signature:
        g.sign()
        store.put_grant(g)
    typer.echo(grant_to_token(g))


@app.command()
def demo(
    auto_approve: bool = typer.Option(
        False, "--auto-approve", help="Auto-approve step 4 so the demo runs non-interactively."
    ),
    mode: str = typer.Option(
        "in-process",
        "--mode",
        help="Demo mode: 'in-process' (v0) or 'gateway' (v1, out-of-process PEP).",
    ),
) -> None:
    """Run the built-in 7-step scripted demo. No LLM, no network, no real money."""
    from actenon.security_posture import declare_process_development_intent

    # A scripted local demo: explicit development intent for this process
    # (refused when ACTENON_ENV declares a non-development environment).
    declare_process_development_intent("permit demo")
    if mode == "in-process":
        from ._demo import run_demo

        _reset_db_for_demo()
        run_demo(auto_approve=auto_approve)
    elif mode == "gateway":
        from ._demo_gateway import run_gateway_demo

        _reset_db_for_demo()
        run_gateway_demo(auto_approve=auto_approve)
    else:
        typer.echo(f"unknown mode: {mode} (use 'in-process' or 'gateway')", err=True)
        raise typer.Exit(code=1)


@app.command()
def version() -> None:
    """Print the version."""
    typer.echo(__version__)


if __name__ == "__main__":
    app()
