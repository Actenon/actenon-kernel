"""FastMCP financial transfer example."""
