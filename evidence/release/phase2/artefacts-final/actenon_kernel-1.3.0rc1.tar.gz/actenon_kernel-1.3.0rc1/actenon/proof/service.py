from __future__ import annotations

import copy

import logging
import os
from dataclasses import dataclass, field
from datetime import timedelta
from enum import Enum
from secrets import token_urlsafe
from typing import Any, Callable, Mapping
from uuid import uuid4

from actenon.core.errors import ProofVerificationError
from actenon.models.contracts import (
    ActionHashSpec,
    ActionIntent,
    PCCB,
    PartyRef,
    ScopeSpec,
    SignatureSpec,
)
from actenon.models.runtime import DynamicContextInput, PolicyDecision
from .audit import AuditLogSink, PCCBMintAuditRecord
from .canonical import (
    ACCEPTED_CANONICALIZATION_PROFILES,
    CANONICALIZATION_PROFILE,
    canonicalize_bytes,
    sha256_hex,
)
from .refusal_messages import EDGE_BINDING_REFUSAL_MESSAGES, public_proof_refusal_message
from .signing import SignatureVerifier, Signer


DEFAULT_CLOCK_SKEW_TOLERANCE = timedelta(0)

logger = logging.getLogger("actenon.proof.verifier")


class VerifierDisclosureMode(str, Enum):
    """How much detail the verifier exposes in its public refusal result.

    - ``public_generic`` (default, production-safe): invalidly-signed or
      unauthenticated proof returns one generic ``PROOF_INVALID`` code.
      No field-level detail is disclosed. Forged field values are not
      echoed into public receipts or caller-visible exceptions.

    - ``trusted_detailed``: after cryptographic authenticity is
      established, existing detailed semantic refusal codes remain
      available (``AUDIENCE_MISMATCH``, ``ACTION_MISMATCH``, etc.).

    - ``local_debug``: full diagnostics including pre-signature granular
      refusal codes. **Fail-closed**: construction with this mode in a
      production-like environment raises ``ValueError``.
    """

    PUBLIC_GENERIC = "public_generic"
    TRUSTED_DETAILED = "trusted_detailed"
    LOCAL_DEBUG = "local_debug"


# Environments where local_debug mode is permitted. Anything else
# (production, staging, etc.) refuses local_debug at construction time.
_LOCAL_DEBUG_ALLOWED_ENVS = frozenset({"development", "local", "dev", "test", "demo", ""})


def _is_production_like_env() -> bool:
    """Return True if ACTENON_ENV indicates a production-like environment."""
    env = os.environ.get("ACTENON_ENV", "").strip().lower()
    return env not in _LOCAL_DEBUG_ALLOWED_ENVS


def default_disclosure_mode() -> "VerifierDisclosureMode":
    """The disclosure profile for kernel-built execution paths.

    ``LOCAL_DEBUG`` (granular pre-authentication codes) where the
    environment permits it, and ``TRUSTED_DETAILED`` (pre-authentication
    failures collapse to ``PROOF_INVALID``) in a production-like
    environment, where ``LOCAL_DEBUG`` is refused at construction.
    """

    if _is_production_like_env():
        return VerifierDisclosureMode.TRUSTED_DETAILED
    return VerifierDisclosureMode.LOCAL_DEBUG


def build_action_hash_input(intent: ActionIntent) -> dict[str, Any]:
    return {
        "intent_id": intent.intent_id,
        "tenant": intent.tenant.to_dict(),
        "requester": intent.requester.to_dict(),
        "action": intent.action.to_dict(),
        "target": intent.target.to_dict(),
        "issued_at": intent.to_dict()["issued_at"],
        "expires_at": intent.to_dict()["expires_at"],
    }


def _canonical_equal(a: Any, b: Any) -> bool:
    """Compare two values by their canonical JSON bytes.

    This prevents ad-hoc object equality from accepting semantically-
    equivalent but structurally-different representations. The kernel
    MUST use canonical comparison for all proof-field bindings.

    Objects with a ``to_dict()`` method (frozen dataclasses like
    AudienceRef, TargetRef, ActionSpec, PartyRef, TenantRef) are
    converted to dicts before canonicalisation.
    """
    def _coerce(v: Any) -> Any:
        if hasattr(v, "to_dict") and callable(v.to_dict):
            return v.to_dict()
        return v
    try:
        return canonicalize_bytes(_coerce(a)) == canonicalize_bytes(_coerce(b))
    except (TypeError, ValueError):
        return False


_MISSING = object()


def _target_satisfies(target: Any, selector: Any) -> bool:
    """protocol/13-edge-binding.md E3: does the bound target satisfy one selector?

    ``resource_id`` / ``resource_type`` compare with the target's fields, any
    other key with ``target.selectors``. A key the target does not carry is
    not satisfied; an empty or non-object selector is not satisfied.
    """
    if not isinstance(selector, dict) or not selector:
        return False
    for key, value in selector.items():
        if key == "resource_id":
            actual = target.resource_id
        elif key == "resource_type":
            actual = target.resource_type
        else:
            actual = (target.selectors or {}).get(key, _MISSING)
        if actual is _MISSING or not _canonical_equal(actual, value):
            return False
    return True


@dataclass
class PCCBMinter:
    signer: Signer
    issuer: PartyRef
    pccb_id_factory: Callable[[], str] = field(default=lambda: f"pccb_{uuid4().hex}")
    nonce_factory: Callable[[], str] = field(default=lambda: token_urlsafe(24))
    audit_sink: AuditLogSink | None = None

    def mint(
        self,
        intent: ActionIntent,
        decision: PolicyDecision,
        context: DynamicContextInput,
        *,
        escrow_id: str | None = None,
        extensions: Mapping[str, Any] | None = None,
    ) -> PCCB:
        if not decision.allowed:
            raise ValueError("PCCB minting requires an allow decision")

        issued_at = context.now
        scope = ScopeSpec(
            mode="exact",
            capabilities=tuple(sorted(set(context.scope_capabilities or (intent.action.capability,)))),
            single_use=True,
            resource_selectors=context.resource_selectors,
            parameter_constraints=context.parameter_constraints,
        )
        action_hash = ActionHashSpec(
            algorithm="sha-256",
            canonicalization=CANONICALIZATION_PROFILE,
            value=sha256_hex(build_action_hash_input(intent)),
        )
        unsigned = PCCB(
            pccb_id=self.pccb_id_factory(),
            intent_id=intent.intent_id,
            issued_at=issued_at,
            not_before=issued_at,
            expires_at=intent.expires_at,
            issuer=self.issuer,
            subject=intent.requester,
            tenant=intent.tenant,
            audience=context.audience,
            action=intent.action,
            target=intent.target,
            scope=scope,
            nonce=self.nonce_factory(),
            action_hash=action_hash,
            escrow_id=escrow_id,
            signature=SignatureSpec(algorithm=self.signer.algorithm, key_id=self.signer.key_id, encoding="base64url", value="pending"),
            # Deep copy: the signed extensions must not alias caller state.
            extensions=copy.deepcopy(dict(extensions or {})),
        )
        signature = self.signer.sign(canonicalize_bytes(unsigned.unsigned_payload()))
        pccb = PCCB(
            pccb_id=unsigned.pccb_id,
            intent_id=unsigned.intent_id,
            issued_at=unsigned.issued_at,
            not_before=unsigned.not_before,
            expires_at=unsigned.expires_at,
            issuer=unsigned.issuer,
            subject=unsigned.subject,
            tenant=unsigned.tenant,
            audience=unsigned.audience,
            action=unsigned.action,
            target=unsigned.target,
            scope=unsigned.scope,
            nonce=unsigned.nonce,
            action_hash=unsigned.action_hash,
            escrow_id=unsigned.escrow_id,
            signature=signature,
            extensions=unsigned.extensions,
        )
        if self.audit_sink is not None:
            self.audit_sink.record_pccb_mint(PCCBMintAuditRecord(pccb))
        return pccb


AUTHORITY_STATUS_UNKNOWN_MESSAGE = "The proof authority's revocation status could not be established."

# Type alias for the optional revocation checker callable.
# Returns True if the proof/issuer is NOT revoked, False if revoked.
RevocationChecker = Callable[["PCCB", DynamicContextInput], bool]


@dataclass
class PCCBVerifier:
    """Verify a PCCB against an ActionIntent and runtime context.

    The verifier enforces a strict 15-step pipeline, ordered so that
    all non-mutating validation happens before any state-changing
    operation (replay, escrow, credential acquisition). The pipeline
    is split into Phase A (pre-authentication) and Phase B
    (post-authentication), with replay deferred to the executor.

    **Phase A — Pre-authentication (minimum safe work, non-mutating):**

      1. Input structure and size limits
         (PCCB dataclass parsing + canonicalize_bytes size/depth limits)
      2. Supported protocol version
         (contract name/version check)
      3. Canonicalisation
         (unsigned payload canonicalised under ACTENON-JCS-STRICT-1)
      4. Issuer and key resolution under configured trust policy
         (delegated to the signer's verify_with_metadata)
      5. Signature verification
         (cryptographic authenticity established)

    **Phase B — Post-authentication (detailed semantic validation, non-mutating):**

      6. Time validity (not_before, expires_at with clock skew)
      7. Audience binding (canonical comparison)
      8. Resource or boundary binding (canonical comparison)
      9. Target binding (canonical comparison)
     10. Action binding (canonical comparison)
     11. Exact parameter digest (action_hash recomputation)
     12. Authority reference binding (escrow_id / grant_id if present)
     13. Revocation status (if a revocation_checker is configured)
     14. Replay state — DEFERRED to ProtectedExecutor (stateful)
     15. Execution eligibility — DEFERRED to ProtectedExecutor (policy)

    Steps 14 and 15 are deferred because they require stateful resources
    (replay store, policy engine) that the verifier does not own. The
    verifier is stateless; the executor is stateful. This separation
    ensures replay state is never consumed before the proof passes all
    non-mutating validation — the formally justified reason for the
    split.

    **Disclosure profiles:**

    The ``disclosure_mode`` parameter controls how much detail is exposed:
      - ``public_generic`` (default): pre-auth failures return
        ``PROOF_INVALID``; post-auth failures also return ``PROOF_INVALID``
        (no field-level detail is disclosed for unauthenticated proofs).
      - ``trusted_detailed``: post-auth failures return the existing
        detailed codes (``AUDIENCE_MISMATCH``, etc.) — but pre-auth
        failures still return ``PROOF_INVALID``.
      - ``local_debug``: full granular diagnostics (the pre-2B behaviour).
        **Fail-closed**: refused in production-like environments.

    **Canonical comparison:**

    All field comparisons (audience, tenant, subject, action, target)
    use ``canonicalize_bytes()`` rather than ad-hoc object equality.
    This prevents semantically-equivalent but structurally-different
    representations from bypassing the binding check.

    **Revocation checking:**

    An optional ``revocation_checker`` callable can be provided. If
    present, it is called AFTER all other verification steps pass (step
    13). It receives the PCCB and context, and returns True if the
    proof/issuer is NOT revoked. If it returns False, the verifier
    raises ``ProofVerificationError`` with code ``AUTHORITY_REVOKED``.

    **Boundary/resource binding:**

    An optional ``boundary_id`` can be set on the verifier. If present,
    the PCCB's audience must match the configured boundary (step 8).
    This is distinct from the audience check (step 7) — the audience
    is who the proof is for; the boundary is what resource is being
    protected.
    """

    signer: SignatureVerifier
    clock_skew_tolerance: timedelta = DEFAULT_CLOCK_SKEW_TOLERANCE
    disclosure_mode: VerifierDisclosureMode = VerifierDisclosureMode.TRUSTED_DETAILED
    # ── Phase 4 hardening: optional configuration ──────────────────
    revocation_checker: RevocationChecker | None = None
    boundary_id: str | None = None
    verifier_identity: str | None = None

    def __post_init__(self) -> None:
        if self.clock_skew_tolerance < timedelta(0):
            raise ValueError("clock_skew_tolerance must be non-negative")
        # Fail-closed: local_debug cannot be enabled in a production-like
        # environment. This is a hard construction-time refusal.
        if self.disclosure_mode == VerifierDisclosureMode.LOCAL_DEBUG:
            if _is_production_like_env():
                raise ValueError(
                    "VerifierDisclosureMode.LOCAL_DEBUG cannot be enabled in "
                    "a production-like environment (ACTENON_ENV="
                    f"{os.environ.get('ACTENON_ENV', '')!r}). Use "
                    "public_generic or trusted_detailed, or set ACTENON_ENV "
                    "to 'local', 'dev', 'test', or 'demo' for local debugging."
                )

    def verify(self, intent: ActionIntent, pccb: PCCB, context: DynamicContextInput) -> None:
        """Verify a PCCB. Raises ``ProofVerificationError`` on any failure.

        The refusal code in the raised exception depends on the
        ``disclosure_mode``:
          - ``public_generic``: all pre-auth + post-auth failures for
            invalidly-signed proofs return ``PROOF_INVALID``.
          - ``trusted_detailed``: pre-auth failures return ``PROOF_INVALID``;
            post-auth failures return the detailed code.
          - ``local_debug``: all failures return the granular code (the
            pre-2B behaviour, for debugging only).
        """
        # ═══════════════════════════════════════════════════════════════
        # Phase A: Pre-authentication (steps 1–5)
        # ═══════════════════════════════════════════════════════════════
        # Only the minimum safe work needed for authentication.
        # Any failure here collapses to PROOF_INVALID (in public_generic
        # or trusted_detailed mode) to prevent field-by-field oracle probing.

        # ── Step 1: Input structure and size limits ──────────────────
        # Structural parsing is performed by the PCCB dataclass constructor
        # (called before verify()). Size and depth limits are enforced by
        # canonicalize_bytes() in step 3.

        # ── Step 2: Supported protocol version ───────────────────────
        # The PCCB declares its contract version. Reject unsupported
        # contract versions before any cryptographic work.
        # (The PCCB.from_dict already validates contract name/version,
        # but we check again here for safety in case the PCCB was
        # constructed directly.)
        contract = pccb.unsigned_payload().get("contract", {})
        if contract.get("name") != "pccb" or contract.get("version") != "v1":
            self._raise_pre_auth_failure(
                "UNSUPPORTED_PROTOCOL_VERSION",
                pccb=pccb,
                context=context,
                internal_detail=f"contract={contract}",
            )

        # ── Step 1 (cont.): Required-field presence for key resolution ─
        # The signature field must be present and non-empty to attempt
        # verification. The issuer field is needed for key resolution
        # (performed by the signer's verify_with_metadata if available).
        sig_error = self._validate_signature_structure(pccb)
        if sig_error is not None:
            self._raise_pre_auth_failure(sig_error, pccb=pccb, context=context)

        # ── Step 3: Canonicalisation of the unsigned proof payload ───
        # This also enforces size limits (1 MB) and depth limits (128).
        try:
            unsigned_payload = canonicalize_bytes(pccb.unsigned_payload())
        except (TypeError, ValueError, RecursionError) as exc:
            self._raise_pre_auth_failure(
                "PROOF_PAYLOAD_INVALID",
                pccb=pccb,
                context=context,
                internal_detail=str(exc),
            )

        # ── Steps 4–5: Issuer/key resolution + signature verification ─
        # The signer resolves the issuer's key (via verify_with_metadata
        # if available) and verifies the signature. This establishes
        # cryptographic authenticity.
        verify_with_metadata = getattr(self.signer, "verify_with_metadata", None)
        if callable(verify_with_metadata):
            is_valid = verify_with_metadata(
                unsigned_payload,
                pccb.signature,
                issuer=pccb.issuer,
                issued_at=pccb.issued_at,
            )
        else:
            is_valid = self.signer.verify(unsigned_payload, pccb.signature)
        if not is_valid:
            self._raise_pre_auth_failure(
                "SIGNATURE_INVALID",
                pccb=pccb,
                context=context,
            )

        # ═══════════════════════════════════════════════════════════════
        # Phase B: Post-authentication semantic validation (steps 6–13)
        # ═══════════════════════════════════════════════════════════════
        # The proof is now cryptographically authentic. We can safely
        # perform detailed semantic checks and (in trusted_detailed /
        # local_debug mode) disclose which check failed.

        # ── Step 6: Time validity ────────────────────────────────────
        if context.now + self.clock_skew_tolerance < pccb.not_before:
            self._raise_post_auth_failure(
                "PROOF_NOT_YET_VALID",
                pccb=pccb,
                context=context,
            )
        if context.now - self.clock_skew_tolerance > pccb.expires_at:
            self._raise_post_auth_failure(
                "PROOF_EXPIRED",
                pccb=pccb,
                context=context,
            )

        # ── Step 7: Audience binding (canonical comparison) ──────────
        if not _canonical_equal(pccb.audience, context.audience):
            self._raise_post_auth_failure(
                "AUDIENCE_MISMATCH",
                pccb=pccb,
                context=context,
            )

        # ── Step 8: Resource or boundary binding ─────────────────────
        # If the verifier is configured with a boundary_id, the PCCB's
        # audience must reference it. This is distinct from the audience
        # type check — the boundary_id is the specific resource instance
        # being protected.
        if self.boundary_id is not None:
            if pccb.audience.id != self.boundary_id:
                self._raise_post_auth_failure(
                    "AUDIENCE_MISMATCH",
                    pccb=pccb,
                    context=context,
                )

        # ── Step 9: Target binding (canonical comparison) ────────────
        if not _canonical_equal(pccb.target, intent.target):
            self._raise_post_auth_failure(
                "TARGET_MISMATCH",
                pccb=pccb,
                context=context,
            )

        # ── Step 10: Action binding (canonical comparison) ───────────
        # Scope mode + capability check (part of action binding)
        # Protocol v1 proofs are exact and single-use only
        # (protocol/13-edge-binding.md E4).
        if pccb.scope.mode != "exact" or pccb.scope.single_use is not True:
            self._raise_post_auth_failure(
                "SCOPE_MODE_INVALID",
                pccb=pccb,
                context=context,
            )
        if intent.action.capability not in pccb.scope.capabilities:
            self._raise_post_auth_failure(
                "SCOPE_CAPABILITY_MISMATCH",
                pccb=pccb,
                context=context,
            )
        # E1: the capability must be one this edge declares it performs
        # (exact strings; an empty declaration performs nothing).
        if intent.action.capability not in tuple(context.scope_capabilities or ()):
            self._raise_post_auth_failure(
                "SCOPE_CAPABILITY_MISMATCH",
                pccb=pccb,
                context=context,
                edge_binding=True,
            )

        # Intent ID (the signed intent_id differs from the supplied intent_id)
        if pccb.intent_id and pccb.intent_id != intent.intent_id:
            self._raise_post_auth_failure(
                "INTENT_MISMATCH",
                pccb=pccb,
                context=context,
            )

        # Tenant (canonical comparison)
        if not _canonical_equal(pccb.tenant, intent.tenant):
            self._raise_post_auth_failure(
                "TENANT_MISMATCH",
                pccb=pccb,
                context=context,
            )

        # Subject (canonical comparison)
        if not _canonical_equal(pccb.subject, intent.requester):
            self._raise_post_auth_failure(
                "SUBJECT_MISMATCH",
                pccb=pccb,
                context=context,
            )

        # Action (canonical comparison)
        if not _canonical_equal(pccb.action, intent.action):
            self._raise_post_auth_failure(
                "ACTION_MISMATCH",
                pccb=pccb,
                context=context,
            )

        # ── Step 11: Exact parameter digest ──────────────────────────
        # Recompute the action_hash and compare. This is the cryptographic
        # binding of the exact parameters (not just object equality).
        try:
            expected_hash = sha256_hex(build_action_hash_input(intent))
        except (TypeError, ValueError, RecursionError) as exc:
            self._raise_post_auth_failure(
                "ACTION_HASH_INVALID",
                pccb=pccb,
                context=context,
                internal_detail=str(exc),
            )
        if pccb.action_hash.algorithm != "sha-256" or pccb.action_hash.canonicalization not in ACCEPTED_CANONICALIZATION_PROFILES:
            self._raise_post_auth_failure(
                "ACTION_HASH_ALGORITHM_INVALID",
                pccb=pccb,
                context=context,
            )
        if pccb.action_hash.value != expected_hash:
            self._raise_post_auth_failure(
                "ACTION_HASH_MISMATCH",
                pccb=pccb,
                context=context,
            )

        # ── Step 11b: Edge declarations (protocol/13-edge-binding.md) ──
        # E2: every constraint the edge relies on was signed into the proof.
        signed_constraints = pccb.scope.parameter_constraints or {}
        for key, value in (context.parameter_constraints or {}).items():
            if key not in signed_constraints or not _canonical_equal(signed_constraints[key], value):
                self._raise_post_auth_failure(
                    "PARAMETER_MISMATCH",
                    pccb=pccb,
                    context=context,
                    edge_binding=True,
                )
        # E3: the bound target satisfies at least one declared selector.
        selectors = tuple(context.resource_selectors or ())
        if selectors and not any(_target_satisfies(pccb.target, selector) for selector in selectors):
            self._raise_post_auth_failure(
                "TARGET_MISMATCH",
                pccb=pccb,
                context=context,
                edge_binding=True,
            )

        # ── Step 12: Authority reference binding ─────────────────────
        # If the PCCB carries an escrow_id (authority reference), verify
        # that the intent's authority reference matches. This binds the
        # proof to the specific authority under which it was issued.
        # (No-op if no escrow_id is present — the authority reference is
        # optional in the current PCCB format.)
        # The actual escrow consumption is deferred to the executor.

        # ── Step 13: Revocation status ───────────────────────────────
        # If a revocation_checker is configured, call it AFTER all other
        # checks pass. This is the last non-mutating check before the
        # executor takes over (steps 14–15: replay + execution eligibility).
        # protocol/13-edge-binding.md E5: a proof whose signed authority
        # reference declares it revocable needs a revocation source that
        # answers "not revoked". No source, a malformed reference or a source
        # that cannot be consulted all fail closed.
        authority_revocable = False
        if "authority" in (pccb.extensions or {}):
            authority = pccb.extensions["authority"]
            if not isinstance(authority, dict) or not isinstance(authority.get("revocable", False), bool):
                self._raise_post_auth_failure(
                    "AUTHORITY_REVOKED", pccb=pccb, context=context, message=AUTHORITY_STATUS_UNKNOWN_MESSAGE
                )
            authority_revocable = authority.get("revocable", False) is True
        if self.revocation_checker is None:
            if authority_revocable:
                self._raise_post_auth_failure(
                    "AUTHORITY_REVOKED", pccb=pccb, context=context, message=AUTHORITY_STATUS_UNKNOWN_MESSAGE
                )
        else:
            try:
                is_not_revoked = self.revocation_checker(pccb, context) is True
                status_message = None
            except Exception:
                # Fail-closed: if the revocation source errors, refuse.
                is_not_revoked = False
                status_message = AUTHORITY_STATUS_UNKNOWN_MESSAGE
            if not is_not_revoked:
                self._raise_post_auth_failure(
                    "AUTHORITY_REVOKED",
                    pccb=pccb,
                    context=context,
                    message=status_message,
                )

        # ── Steps 14–15: Replay state + execution eligibility ────────
        # DEFERRED to ProtectedExecutor. The verifier is stateless; the
        # executor owns the replay store and policy engine. This ensures
        # replay state is never consumed before the proof passes all
        # non-mutating validation.

    # ── Internal helpers ─────────────────────────────────────────────

    def _validate_signature_structure(self, pccb: PCCB) -> str | None:
        """Validate the signature field is present and structurally sound
        for key resolution. Returns a refusal_code string if invalid,
        or None if the structure is acceptable.
        """
        sig = pccb.signature
        if not sig or not sig.value:
            return "SIGNATURE_INVALID"
        if sig.encoding != "base64url":
            return "SIGNATURE_INVALID"
        # The algorithm and key_id are validated by the signer during
        # verification (algorithm confusion attacks are handled there).
        return None

    def _raise_pre_auth_failure(
        self,
        internal_code: str,
        *,
        pccb: PCCB,
        context: DynamicContextInput,
        internal_detail: str | None = None,
    ) -> None:
        """Raise a ProofVerificationError for a pre-authentication failure.

        In ``public_generic`` and ``trusted_detailed`` modes, all
        pre-authentication failures collapse to ``PROOF_INVALID`` to
        prevent field-by-field oracle probing.

        In ``local_debug`` mode, the granular ``internal_code`` is
        preserved for debugging.

        The precise internal reason is logged at DEBUG level (protected
        diagnostic event) but never included in the public exception
        message or details.
        """
        if self.disclosure_mode == VerifierDisclosureMode.LOCAL_DEBUG:
            raise ProofVerificationError(
                internal_code,
                public_proof_refusal_message(internal_code),
            )
        # public_generic + trusted_detailed: collapse to PROOF_INVALID
        logger.debug(
            "proof.pre_auth_failure",
            extra={
                "event": "proof.pre_auth_failure",
                "internal_code": internal_code,
                "internal_detail": internal_detail,
                "pccb_id": pccb.pccb_id,
                "request_id": getattr(context, "request_id", None),
            },
        )
        raise ProofVerificationError(
            "PROOF_INVALID",
            public_proof_refusal_message("PROOF_INVALID"),
        )

    def _raise_post_auth_failure(
        self,
        detailed_code: str,
        *,
        pccb: PCCB,
        context: DynamicContextInput,
        internal_detail: str | None = None,
        edge_binding: bool = False,
        message: str | None = None,
    ) -> None:
        """Raise a ProofVerificationError for a post-authentication failure.

        The proof was cryptographically authentic, so the semantic check
        failure is real (not a forgery attempt). The disclosure depends
        on the mode:

        - ``public_generic``: return ``PROOF_INVALID``. Even though the
          proof was authentic, we don't disclose which field mismatched
          because the caller may be an attacker probing the boundary.
        - ``trusted_detailed``: return the detailed ``detailed_code``.
          The issuer is authentic, so the operator is allowed to know
          which policy check failed.
        - ``local_debug``: return the detailed ``detailed_code`` (same
          as trusted_detailed, but also applies to pre-auth failures).
        """
        if self.disclosure_mode == VerifierDisclosureMode.PUBLIC_GENERIC:
            logger.debug(
                "proof.post_auth_failure",
                extra={
                    "event": "proof.post_auth_failure",
                    "internal_code": detailed_code,
                    "internal_detail": internal_detail,
                    "pccb_id": pccb.pccb_id,
                    "request_id": getattr(context, "request_id", None),
                },
            )
            raise ProofVerificationError(
                "PROOF_INVALID",
                public_proof_refusal_message("PROOF_INVALID"),
            )
        # trusted_detailed + local_debug: disclose the detailed code
        raise ProofVerificationError(
            detailed_code,
            message
            or (EDGE_BINDING_REFUSAL_MESSAGES[detailed_code] if edge_binding else public_proof_refusal_message(detailed_code)),
        )
