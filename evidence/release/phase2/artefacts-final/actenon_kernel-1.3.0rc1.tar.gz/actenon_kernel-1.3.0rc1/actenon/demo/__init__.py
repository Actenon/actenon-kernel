"""Local proof demo helpers."""

